﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PW_TFinal_V1
{
    public partial class MarcarConsulta : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            btnSubmit.ServerClick += new EventHandler(btnSubmit_Click);
        }

        void btnSubmit_Click(object sender, EventArgs e)
        {
            string CnnString = ConfigurationManager.ConnectionStrings["BaseDadosSQL"].ConnectionString;

             
            string select = "select count(Cod_Consulta) from Consulta";
            SqlConnection SqlCnn = new SqlConnection(CnnString);
            SqlCnn.Open();
            
            SqlCommand Cmd = new SqlCommand(select, SqlCnn);
            Cmd.ExecuteNonQuery();
                    
            Cmd.Parameters.AddWithValue("@Cod_Consulta", (int)Cmd.ExecuteScalar()+1);
            
            string insert = "insert into Consulta(Cod_Consulta,Nome,Data,Hora) values (@Cod_Consulta,@Nome,@Data,@Hora)";
            Cmd.CommandText = insert;
            
            
            Cmd.Parameters.AddWithValue("@Nome", Tipo.SelectedValue);
            string Data = Dia.Text + Mes.Text + Ano.Text;
            Cmd.Parameters.AddWithValue("@Data", Data);
            Cmd.Parameters.AddWithValue("@Hora", Hora.Text);

            Cmd.ExecuteNonQuery();
            
            SqlCnn.Close();
        }

    }
}